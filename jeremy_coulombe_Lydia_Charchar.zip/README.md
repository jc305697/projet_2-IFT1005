projet_2 IFT1005
